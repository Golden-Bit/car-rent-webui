// ignore_for_file: non_constant_identifier_names

//library myrent_sdk;

import 'dart:convert';
import 'package:http/http.dart' as http;

typedef JsonMap = Map<String, dynamic>;

/* ===========================
 *          ENUMS
 * ===========================
 */

/// Sorgente dati della wrapper:
/// - DEFAULT: mock locale
/// - MYRENT: live via adapter/SDK python
enum DataSource { DEFAULT, MYRENT }

extension DataSourceX on DataSource {
  String get value => this == DataSource.MYRENT ? 'MYRENT' : 'DEFAULT';
}

/* ===========================
 *          ERRORS
 * ===========================
 */

/// Eccezione API
class ApiException implements Exception {
  final int statusCode;
  final String body;
  final Uri uri;

  ApiException(this.statusCode, this.body, this.uri);

  @override
  String toString() =>
      'ApiException(statusCode=$statusCode, uri=$uri, body=$body)';
}

/* ===========================
 *          CLIENT
 * ===========================
 */

/// Client principale
class MyrentClient {
  final String baseUrl;
  final String apiKey;
  final http.Client _client;
  final Map<String, String> _defaultHeaders;

  late final String _base; // baseUrl normalizzato (senza trailing slash)

  MyrentClient({
    required this.baseUrl,
    required this.apiKey,
    http.Client? httpClient,
  })  : _client = httpClient ?? http.Client(),
        _defaultHeaders = {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-API-Key': apiKey,
        } {
    _base = baseUrl.replaceAll(RegExp(r'/+$'), '');
  }

  Uri _uri(String path, {Map<String, String>? query}) {
    final p = path.startsWith('/') ? path : '/$path';
    final raw = Uri.parse('$_base$p');
    if (query == null || query.isEmpty) return raw;
    return raw.replace(queryParameters: query);
  }

  /// GET /health
  Future<Health> getHealth() async {
    final uri = _uri('/health');
    final res = await _client.get(uri, headers: _defaultHeaders);
    if (res.statusCode >= 200 && res.statusCode < 300) {
      return Health.fromJson(jsonDecode(res.body) as Map<String, dynamic>);
    }
    throw ApiException(res.statusCode, res.body, uri);
  }

  /// GET /api/v1/touroperator/locations?source=...
  Future<List<Location>> getLocations({DataSource source = DataSource.DEFAULT}) async {
    final uri = _uri(
      '/api/v1/touroperator/locations',
      query: {'source': source.value},
    );

    final res = await _client.get(uri, headers: _defaultHeaders);
    if (res.statusCode >= 200 && res.statusCode < 300) {
      final data = jsonDecode(res.body) as List<dynamic>;
      return data
          .map((e) => Location.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    throw ApiException(res.statusCode, res.body, uri);
  }

  /// POST /api/v1/touroperator/quotations?source=...
  Future<QuotationResponse> createQuotation(
    QuotationRequest req, {
    DataSource source = DataSource.DEFAULT,
  }) async {
    final uri = _uri(
      '/api/v1/touroperator/quotations',
      query: {'source': source.value},
    );

    final res = await _client.post(
      uri,
      headers: _defaultHeaders,
      body: jsonEncode(req.toJson()),
    );

    if (res.statusCode >= 200 && res.statusCode < 300) {
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      return QuotationResponse.fromJson(data);
    }
    throw ApiException(res.statusCode, res.body, uri);
  }

  /// GET /api/v1/touroperator/damages/{plate_or_vin}
  Future<DamagesResponse> getDamages(
    String plateOrVin, {
    String? acceptLanguage,
  }) async {
    final uri = _uri('/api/v1/touroperator/damages/$plateOrVin');

    final headers = Map<String, String>.from(_defaultHeaders);
    if (acceptLanguage != null && acceptLanguage.isNotEmpty) {
      headers['Accept-Language'] = acceptLanguage;
    }

    final res = await _client.get(uri, headers: headers);
    if (res.statusCode >= 200 && res.statusCode < 300) {
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      return DamagesResponse.fromJson(data);
    }
    throw ApiException(res.statusCode, res.body, uri);
  }

  /// GET /api/v1/touroperator/vehicles
  /// Legge il catalogo impaginato, utile per avere gli ID "sorgente".
  Future<VehiclesPage> listVehicles({
    String? location,
    int skip = 0,
    int pageSize = 25,
  }) async {
    final qs = <String, String>{
      'skip': '$skip',
      'page_size': '$pageSize',
      if (location != null && location.isNotEmpty) 'location': location,
    };

    final uri = _uri('/api/v1/touroperator/vehicles', query: qs);
    final res = await _client.get(uri, headers: _defaultHeaders);

    if (res.statusCode >= 200 && res.statusCode < 300) {
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      return VehiclesPage.fromJson(data);
    }
    throw ApiException(res.statusCode, res.body, uri);
  }

  /// GET /api/v1/touroperator/vehicles/{id}
  Future<VehicleGroupRaw> getVehicleById(String vehicleId) async {
    final uri = _uri('/api/v1/touroperator/vehicles/$vehicleId');
    final res = await _client.get(uri, headers: _defaultHeaders);

    if (res.statusCode >= 200 && res.statusCode < 300) {
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      return VehicleGroupRaw.fromJson(data);
    }
    throw ApiException(res.statusCode, res.body, uri);
  }

    /// POST /api/v1/touroperator/reservations/compose?source=...
  Future<ReservationComposeResponse> createReservationCompose(
    ReservationComposeRequest req, {
    DataSource source = DataSource.MYRENT,
  }) async {
    final uri = _uri(
      '/api/v1/touroperator/reservations/compose',
      query: {'source': source.value},
    );

    final res = await _client.post(
      uri,
      headers: _defaultHeaders,
      body: jsonEncode(req.toJson()),
    );

    if (res.statusCode >= 200 && res.statusCode < 300) {
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      return ReservationComposeResponse.fromJson(data);
    }
    throw ApiException(res.statusCode, res.body, uri);
  }

  /// GET /api/v1/touroperator/reservations/{reservation_id}?source=...
  Future<ReservationFullDetailsResponse> getReservationDetailsByInternalId(
    String reservationId, {
    DataSource source = DataSource.MYRENT,
  }) async {
    final uri = _uri(
      '/api/v1/touroperator/reservations/$reservationId',
      query: {'source': source.value},
    );

    final res = await _client.get(uri, headers: _defaultHeaders);

    if (res.statusCode >= 200 && res.statusCode < 300) {
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      return ReservationFullDetailsResponse.fromJson(data);
    }
    throw ApiException(res.statusCode, res.body, uri);
  }

  /// GET /api/v1/touroperator/reservations/details/by-code?reservationCode=...&customerEmail=...&reservationDate=...&source=...
  Future<ReservationFullDetailsResponse> getReservationDetailsByCode({
    required String reservationCode,
    required String customerEmail,
    required String reservationDate, // formato yyyy-MM-dd
    DataSource source = DataSource.MYRENT,
  }) async {
    final uri = _uri(
      '/api/v1/touroperator/reservations/details/by-code',
      query: {
        'reservationCode': reservationCode,
        'customerEmail': customerEmail,
        'reservationDate': reservationDate,
        'source': source.value,
      },
    );

    final res = await _client.get(uri, headers: _defaultHeaders);

    if (res.statusCode >= 200 && res.statusCode < 300) {
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      return ReservationFullDetailsResponse.fromJson(data);
    }
    throw ApiException(res.statusCode, res.body, uri);
  }

  void close() => _client.close();
}

/// Helper: formatta DateTime in ISO8601 con suffisso Z
String isoZ(DateTime dt) {
  return dt.toUtc().toIso8601String().split('.').first + 'Z';
}

/* ===========================
 *          MODELS
 * ===========================
 */

class Health {
  final String status;
  final String? version;

  Health({required this.status, this.version});

  factory Health.fromJson(Map<String, dynamic> json) => Health(
        status: json['status'] as String,
        version: json['version'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'status': status,
        if (version != null) 'version': version,
      };
}

/* ------ Locations ------ */

class WeekOfDay {
  final int dayOfTheWeek;
  final String dayOfTheWeekName;
  final String startTime;
  final String endTime;

  WeekOfDay({
    required this.dayOfTheWeek,
    required this.dayOfTheWeekName,
    required this.startTime,
    required this.endTime,
  });

  factory WeekOfDay.fromJson(Map<String, dynamic> json) => WeekOfDay(
        dayOfTheWeek: json['dayOfTheWeek'] as int,
        dayOfTheWeekName: json['dayOfTheWeekName'] as String,
        startTime: json['startTime'] as String,
        endTime: json['endTime'] as String,
      );

  Map<String, dynamic> toJson() => {
        'dayOfTheWeek': dayOfTheWeek,
        'dayOfTheWeekName': dayOfTheWeekName,
        'startTime': startTime,
        'endTime': endTime,
      };
}

class Closing {
  final int dayOfTheWeek;
  final String dayOfTheWeekName;
  final String startTime;
  final String endTime;

  Closing({
    required this.dayOfTheWeek,
    required this.dayOfTheWeekName,
    required this.startTime,
    required this.endTime,
  });

  factory Closing.fromJson(Map<String, dynamic> json) => Closing(
        dayOfTheWeek: json['dayOfTheWeek'] as int,
        dayOfTheWeekName: json['dayOfTheWeekName'] as String,
        startTime: json['startTime'] as String,
        endTime: json['endTime'] as String,
      );

  Map<String, dynamic> toJson() => {
        'dayOfTheWeek': dayOfTheWeek,
        'dayOfTheWeekName': dayOfTheWeekName,
        'startTime': startTime,
        'endTime': endTime,
      };
}

class Location {
  final String locationCode;
  final String locationName;
  final String? locationAddress;
  final String? locationNumber;
  final String? locationCity;
  final int locationType;
  final String? telephoneNumber;
  final String? cellNumber;
  final String? email;
  final double? latitude;
  final double? longitude;
  final bool isAirport;
  final bool isRailway;
  final bool? isAlwaysOpentrue;
  final bool isCarSharingEnabled;
  final bool allowPickUpDropOffOutOfHours;
  final bool hasKeyBox;
  final String? morningStartTime;
  final String? morningStopTime;
  final String? afternoonStartTime;
  final String? afternoonStopTime;
  final String? locationInfoEN;
  final String? locationInfoLocal;
  final List<WeekOfDay> openings;
  final List<Closing>? closing;
  final List<Map<String, dynamic>>? festivity;
  final int? minimumLeadTimeInHour;
  final String? country;
  final String? zipCode;

  Location({
    required this.locationCode,
    required this.locationName,
    this.locationAddress,
    this.locationNumber,
    this.locationCity,
    this.locationType = 3,
    this.telephoneNumber,
    this.cellNumber,
    this.email,
    this.latitude,
    this.longitude,
    this.isAirport = false,
    this.isRailway = false,
    this.isAlwaysOpentrue,
    this.isCarSharingEnabled = false,
    this.allowPickUpDropOffOutOfHours = false,
    this.hasKeyBox = false,
    this.morningStartTime,
    this.morningStopTime,
    this.afternoonStartTime,
    this.afternoonStopTime,
    this.locationInfoEN,
    this.locationInfoLocal,
    this.openings = const [],
    this.closing,
    this.festivity,
    this.minimumLeadTimeInHour,
    this.country,
    this.zipCode,
  });

  factory Location.fromJson(Map<String, dynamic> json) => Location(
        locationCode: json['locationCode'] as String,
        locationName: json['locationName'] as String,
        locationAddress: json['locationAddress'] as String?,
        locationNumber: json['locationNumber'] as String?,
        locationCity: json['locationCity'] as String?,
        locationType: (json['locationType'] ?? 3) as int,
        telephoneNumber: json['telephoneNumber'] as String?,
        cellNumber: json['cellNumber'] as String?,
        email: json['email'] as String?,
        latitude: (json['latitude'] as num?)?.toDouble(),
        longitude: (json['longitude'] as num?)?.toDouble(),
        isAirport: (json['isAirport'] ?? false) as bool,
        isRailway: (json['isRailway'] ?? false) as bool,
        isAlwaysOpentrue: json['isAlwaysOpentrue'] as bool?,
        isCarSharingEnabled: (json['isCarSharingEnabled'] ?? false) as bool,
        allowPickUpDropOffOutOfHours:
            (json['allowPickUpDropOffOutOfHours'] ?? false) as bool,
        hasKeyBox: (json['hasKeyBox'] ?? false) as bool,
        morningStartTime: json['morningStartTime'] as String?,
        morningStopTime: json['morningStopTime'] as String?,
        afternoonStartTime: json['afternoonStartTime'] as String?,
        afternoonStopTime: json['afternoonStopTime'] as String?,
        locationInfoEN: json['locationInfoEN'] as String?,
        locationInfoLocal: json['locationInfoLocal'] as String?,
        openings: (json['openings'] as List<dynamic>? ?? [])
            .map((e) => WeekOfDay.fromJson(e as Map<String, dynamic>))
            .toList(),
        closing: (json['closing'] as List<dynamic>?)
            ?.map((e) => Closing.fromJson(e as Map<String, dynamic>))
            .toList(),
        festivity: (json['festivity'] as List<dynamic>?)
            ?.map((e) => Map<String, dynamic>.from(e as Map))
            .toList(),
        minimumLeadTimeInHour: json['minimumLeadTimeInHour'] as int?,
        country: json['country'] as String?,
        zipCode: json['zipCode'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'locationCode': locationCode,
        'locationName': locationName,
        if (locationAddress != null) 'locationAddress': locationAddress,
        if (locationNumber != null) 'locationNumber': locationNumber,
        if (locationCity != null) 'locationCity': locationCity,
        'locationType': locationType,
        if (telephoneNumber != null) 'telephoneNumber': telephoneNumber,
        if (cellNumber != null) 'cellNumber': cellNumber,
        if (email != null) 'email': email,
        if (latitude != null) 'latitude': latitude,
        if (longitude != null) 'longitude': longitude,
        'isAirport': isAirport,
        'isRailway': isRailway,
        if (isAlwaysOpentrue != null) 'isAlwaysOpentrue': isAlwaysOpentrue,
        'isCarSharingEnabled': isCarSharingEnabled,
        'allowPickUpDropOffOutOfHours': allowPickUpDropOffOutOfHours,
        'hasKeyBox': hasKeyBox,
        if (morningStartTime != null) 'morningStartTime': morningStartTime,
        if (morningStopTime != null) 'morningStopTime': morningStopTime,
        if (afternoonStartTime != null)
          'afternoonStartTime': afternoonStartTime,
        if (afternoonStopTime != null) 'afternoonStopTime': afternoonStopTime,
        if (locationInfoEN != null) 'locationInfoEN': locationInfoEN,
        if (locationInfoLocal != null) 'locationInfoLocal': locationInfoLocal,
        'openings': openings.map((e) => e.toJson()).toList(),
        if (closing != null) 'closing': closing!.map((e) => e.toJson()).toList(),
        if (festivity != null) 'festivity': festivity,
        if (minimumLeadTimeInHour != null)
          'minimumLeadTimeInHour': minimumLeadTimeInHour,
        if (country != null) 'country': country,
        if (zipCode != null) 'zipCode': zipCode,
      };
}

/* ------ Quotations ------ */

class VehMakeModel {
  final String Name;

  VehMakeModel({required this.Name});

  factory VehMakeModel.fromJson(Map<String, dynamic> json) =>
      VehMakeModel(Name: json['Name'] as String);

  Map<String, dynamic> toJson() => {'Name': Name};
}

class BookingVehicle {
  final String? id;

  // Codici
  final String Code;
  final String? CodeContext;
  final String? nationalCode; // alias "nationalCode"

  // Nome/branding
  final List<VehMakeModel> vehMakeModels; // JSON: "VehMakeModel"
  final String? model;
  final String? brand;
  final String? version;

  // Macro / tipo
  final String? VendorCarMacroGroup;
  final String? VendorCarType;

  // Specifiche veicolo
  final int? seats;
  final int? doors;
  /// 'M' = Manuale, 'A' = Automatico
  final String? transmission;
  /// 'PETROL' | 'DIESEL' | 'ELECTRIC' | ...
  final String? fuel;
  final bool? aircon;
  final String? imageUrl;   // preferisci questa chiave; fallback su "image_url"
  final double? dailyRate;  // preferisci questa chiave; fallback su "daily_rate"

  // Altro
  final int? km;
  final String? color;
  final String? plate_no;
  final String? chasis_no;
  final List<String> locations;
  final List<String> plates;

  BookingVehicle({
    this.id,
    required this.Code,
    this.CodeContext,
    this.nationalCode,
    this.vehMakeModels = const [],
    this.model,
    this.brand,
    this.version,
    this.VendorCarMacroGroup,
    this.VendorCarType,
    this.seats,
    this.doors,
    this.transmission,
    this.fuel,
    this.aircon,
    this.imageUrl,
    this.dailyRate,
    this.km,
    this.color,
    this.plate_no,
    this.chasis_no,
    this.locations = const [],
    this.plates = const [],
  });

  factory BookingVehicle.fromJson(Map<String, dynamic> json) {
    final dr = json['dailyRate'] ?? json['daily_rate'];
    final img = json['imageUrl'] ?? json['image_url'];

    return BookingVehicle(
      id: json['id']?.toString(),
      Code: json['Code'] as String,
      CodeContext: json['CodeContext'] as String?,
      nationalCode: json['nationalCode'] as String?,
      vehMakeModels: (json['VehMakeModel'] as List<dynamic>? ?? [])
          .map((e) => VehMakeModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      model: json['model'] as String?,
      brand: json['brand'] as String?,
      version: json['version'] as String?,
      VendorCarMacroGroup: json['VendorCarMacroGroup'] as String?,
      VendorCarType: json['VendorCarType'] as String?,
      seats: (json['seats'] as num?)?.toInt(),
      doors: (json['doors'] as num?)?.toInt(),
      transmission: json['transmission'] as String?,
      fuel: json['fuel'] as String?,
      aircon: json['aircon'] as bool?,
      imageUrl: img as String?,
      dailyRate: dr == null ? null : (dr as num).toDouble(),
      km: (json['km'] as num?)?.toInt(),
      color: json['color'] as String?,
      plate_no: json['plate_no'] as String?,
      chasis_no: json['chasis_no'] as String?,
      locations: (json['locations'] as List<dynamic>? ?? [])
          .map((e) => e.toString())
          .toList(),
      plates: (json['plates'] as List<dynamic>? ?? [])
          .map((e) => e.toString())
          .toList(),
    );
  }

  Map<String, dynamic> toJson() => {
        if (id != null) 'id': id,
        'Code': Code,
        if (CodeContext != null) 'CodeContext': CodeContext,
        if (nationalCode != null) 'nationalCode': nationalCode,
        'VehMakeModel': vehMakeModels.map((e) => e.toJson()).toList(),
        if (model != null) 'model': model,
        if (brand != null) 'brand': brand,
        if (version != null) 'version': version,
        if (VendorCarMacroGroup != null)
          'VendorCarMacroGroup': VendorCarMacroGroup,
        if (VendorCarType != null) 'VendorCarType': VendorCarType,
        if (seats != null) 'seats': seats,
        if (doors != null) 'doors': doors,
        if (transmission != null) 'transmission': transmission,
        if (fuel != null) 'fuel': fuel,
        if (aircon != null) 'aircon': aircon,
        if (imageUrl != null) 'imageUrl': imageUrl,
        if (dailyRate != null) 'dailyRate': dailyRate,
        if (km != null) 'km': km,
        if (color != null) 'color': color,
        if (plate_no != null) 'plate_no': plate_no,
        if (chasis_no != null) 'chasis_no': chasis_no,
        if (locations.isNotEmpty) 'locations': locations,
        if (plates.isNotEmpty) 'plates': plates,
      };

  bool get isAutomatic => (transmission ?? '').toUpperCase() == 'A';
  bool get hasAircon => aircon == true;
  int? get idAsInt => id == null ? null : int.tryParse(id!);
}

class VehicleParameter {
  // JSON keys hanno i due punti (!)
  final String name;
  final String description;
  final int position;
  final String fileUrl;

  VehicleParameter({
    required this.name,
    required this.description,
    required this.position,
    required this.fileUrl,
  });

  factory VehicleParameter.fromJson(Map<String, dynamic> json) =>
      VehicleParameter(
        name: json['name :'] as String,
        description: json['description :'] as String,
        position: (json['position :'] as num).toInt(),
        fileUrl: (json['fileUrl :'] ?? '') as String,
      );

  Map<String, dynamic> toJson() => {
        'name :': name,
        'description :': description,
        'position :': position,
        'fileUrl :': fileUrl,
      };
}

class GroupPic {
  final int id;
  final String? url;

  GroupPic({required this.id, this.url});

  factory GroupPic.fromJson(Map<String, dynamic> json) => GroupPic(
        id: (json['id'] as num).toInt(),
        url: json['url'] as String?,
      );

  Map<String, dynamic> toJson() => {'id': id, if (url != null) 'url': url};
}

class Charge {
  final double Amount;
  final String CurrencyCode;
  final String Description;
  final bool IncludedInEstTotalInd;
  final bool IncludedInRate;
  final bool TaxInclusive;

  Charge({
    required this.Amount,
    required this.CurrencyCode,
    required this.Description,
    this.IncludedInEstTotalInd = true,
    this.IncludedInRate = false,
    this.TaxInclusive = false,
  });

  factory Charge.fromJson(Map<String, dynamic> json) => Charge(
        Amount: (json['Amount'] as num).toDouble(),
        CurrencyCode: json['CurrencyCode'] as String,
        Description: json['Description'] as String,
        IncludedInEstTotalInd:
            (json['IncludedInEstTotalInd'] ?? true) as bool,
        IncludedInRate: (json['IncludedInRate'] ?? false) as bool,
        TaxInclusive: (json['TaxInclusive'] ?? false) as bool,
      );

  Map<String, dynamic> toJson() => {
        'Amount': Amount,
        'CurrencyCode': CurrencyCode,
        'Description': Description,
        'IncludedInEstTotalInd': IncludedInEstTotalInd,
        'IncludedInRate': IncludedInRate,
        'TaxInclusive': TaxInclusive,
      };
}

class Equipment {
  final String Description;
  final String EquipType;
  final int Quantity;
  final bool isMultipliable;
  final String? optionalImage;

  Equipment({
    required this.Description,
    required this.EquipType,
    this.Quantity = 1,
    this.isMultipliable = true,
    this.optionalImage,
  });

  factory Equipment.fromJson(Map<String, dynamic> json) => Equipment(
        Description: json['Description'] as String,
        EquipType: json['EquipType'] as String,
        Quantity: (json['Quantity'] as num?)?.toInt() ?? 1,
        isMultipliable: (json['isMultipliable'] ?? true) as bool,
        optionalImage: json['optionalImage'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'Description': Description,
        'EquipType': EquipType,
        'Quantity': Quantity,
        'isMultipliable': isMultipliable,
        if (optionalImage != null) 'optionalImage': optionalImage,
      };
}

class OptionalItem {
  final Charge ChargeObj;
  final Equipment EquipmentObj;

  OptionalItem({required this.ChargeObj, required this.EquipmentObj});

  factory OptionalItem.fromJson(Map<String, dynamic> json) => OptionalItem(
        ChargeObj: Charge.fromJson(json['Charge'] as Map<String, dynamic>),
        EquipmentObj:
            Equipment.fromJson(json['Equipment'] as Map<String, dynamic>),
      );

  Map<String, dynamic> toJson() => {
        'Charge': ChargeObj.toJson(),
        'Equipment': EquipmentObj.toJson(),
      };
}

class TotalCharge {
  final double EstimatedTotalAmount;
  final double RateTotalAmount;

  TotalCharge({
    required this.EstimatedTotalAmount,
    required this.RateTotalAmount,
  });

  factory TotalCharge.fromJson(Map<String, dynamic> json) => TotalCharge(
        EstimatedTotalAmount:
            (json['EstimatedTotalAmount'] as num).toDouble(),
        RateTotalAmount: (json['RateTotalAmount'] as num).toDouble(),
      );

  Map<String, dynamic> toJson() => {
        'EstimatedTotalAmount': EstimatedTotalAmount,
        'RateTotalAmount': RateTotalAmount,
      };
}

/// ✅ UPDATE: ora VehicleStatus può contenere optionals e TotalCharge (schema nuovo)
class VehicleStatus {
  final String Status;
  final Map<String, dynamic>? Reference;
  final BookingVehicle Vehicle;
  final List<VehicleParameter>? vehicleParameter;
  final List<String>? vehicleExtraImage;
  final GroupPic? groupPic;

  /// ✅ NEW (schema nuovo): optionals per veicolo
  final List<OptionalItem> optionals;

  /// ✅ NEW (schema nuovo): TotalCharge per veicolo (chiave JSON: "TotalCharge")
  final TotalCharge? TotalChargeJson;

  VehicleStatus({
    required this.Status,
    required this.Reference,
    required this.Vehicle,
    this.vehicleParameter,
    this.vehicleExtraImage,
    this.groupPic,
    this.optionals = const [],
    this.TotalChargeJson,
  });

  factory VehicleStatus.fromJson(Map<String, dynamic> json) => VehicleStatus(
        Status: json['Status'] as String,
        Reference: (json['Reference'] as Map?)?.cast<String, dynamic>(),
        Vehicle: BookingVehicle.fromJson(
            json['Vehicle'] as Map<String, dynamic>),
        vehicleParameter: (json['vehicleParameter'] as List<dynamic>?)
            ?.map((e) => VehicleParameter.fromJson(e as Map<String, dynamic>))
            .toList(),
        vehicleExtraImage: (json['vehicleExtraImage'] as List<dynamic>?)
            ?.map((e) => e.toString())
            .toList(),
        groupPic: json['groupPic'] == null
            ? null
            : GroupPic.fromJson(json['groupPic'] as Map<String, dynamic>),

        // ✅ schema nuovo
        optionals: (json['optionals'] as List<dynamic>? ?? [])
            .map((e) => OptionalItem.fromJson(e as Map<String, dynamic>))
            .toList(),
        TotalChargeJson: json['TotalCharge'] == null
            ? null
            : TotalCharge.fromJson(json['TotalCharge'] as Map<String, dynamic>),
      );

  Map<String, dynamic> toJson() => {
        'Status': Status,
        if (Reference != null) 'Reference': Reference,
        'Vehicle': Vehicle.toJson(),
        if (vehicleParameter != null)
          'vehicleParameter': vehicleParameter!.map((e) => e.toJson()).toList(),
        if (vehicleExtraImage != null) 'vehicleExtraImage': vehicleExtraImage,
        if (groupPic != null) 'groupPic': groupPic!.toJson(),

        // ✅ schema nuovo
        if (optionals.isNotEmpty)
          'optionals': optionals.map((e) => e.toJson()).toList(),
        if (TotalChargeJson != null) 'TotalCharge': TotalChargeJson!.toJson(),
      };
}

class QuotationData {
  final int total;
  final String PickUpLocation;
  final String ReturnLocation;
  final String PickUpDateTime;
  final String ReturnDateTime;
  final List<VehicleStatus> Vehicles;

  /// ⚠️ BACKWARD-COMPAT (vecchia wrapper):
  /// prima erano a root; ora (nuova wrapper) NON arrivano più.
  /// Li manteniamo opzionali e (se assenti) li ricaviamo dal primo veicolo.
  final List<OptionalItem> optionals;
  final TotalCharge? TotalChargeJson;

  QuotationData({
    required this.total,
    required this.PickUpLocation,
    required this.ReturnLocation,
    required this.PickUpDateTime,
    required this.ReturnDateTime,
    required this.Vehicles,
    this.optionals = const [],
    this.TotalChargeJson,
  });

  factory QuotationData.fromJson(Map<String, dynamic> json) {
    final vehicles = (json['Vehicles'] as List<dynamic>)
        .map((e) => VehicleStatus.fromJson(e as Map<String, dynamic>))
        .toList();

    // root (vecchio schema)
    final rootOptionals = (json['optionals'] as List<dynamic>?)
            ?.map((e) => OptionalItem.fromJson(e as Map<String, dynamic>))
            .toList() ??
        const <OptionalItem>[];

    final rootTotalCharge = json['TotalCharge'] == null
        ? null
        : TotalCharge.fromJson(json['TotalCharge'] as Map<String, dynamic>);

    // fallback (nuovo schema): prendo dal primo veicolo (utile per non rompere UI legacy)
    final fallbackOptionals = vehicles.isNotEmpty ? vehicles.first.optionals : const <OptionalItem>[];
    final fallbackTotalCharge = vehicles.isNotEmpty ? vehicles.first.TotalChargeJson : null;

    return QuotationData(
      total: (json['total'] as num).toInt(),
      PickUpLocation: json['PickUpLocation'] as String,
      ReturnLocation: json['ReturnLocation'] as String,
      PickUpDateTime: json['PickUpDateTime'] as String,
      ReturnDateTime: json['ReturnDateTime'] as String,
      Vehicles: vehicles,
      optionals: rootOptionals.isNotEmpty ? rootOptionals : fallbackOptionals,
      TotalChargeJson: rootTotalCharge ?? fallbackTotalCharge,
    );
  }

  Map<String, dynamic> toJson() => {
        'total': total,
        'PickUpLocation': PickUpLocation,
        'ReturnLocation': ReturnLocation,
        'PickUpDateTime': PickUpDateTime,
        'ReturnDateTime': ReturnDateTime,
        'Vehicles': Vehicles.map((e) => e.toJson()).toList(),

        // compat
        if (optionals.isNotEmpty)
          'optionals': optionals.map((e) => e.toJson()).toList(),
        if (TotalChargeJson != null) 'TotalCharge': TotalChargeJson!.toJson(),
      };
}

class QuotationResponse {
  final QuotationData data;

  QuotationResponse({required this.data});

  factory QuotationResponse.fromJson(Map<String, dynamic> json) =>
      QuotationResponse(
        data: QuotationData.fromJson(json['data'] as Map<String, dynamic>),
      );

  Map<String, dynamic> toJson() => {'data': data.toJson()};
}

class QuotationRequest {
  final String dropOffLocation;
  final String endDate; // ISO-8601 con Z
  final String pickupLocation;
  final String startDate; // ISO-8601 con Z
  final dynamic age; // int o string
  final String? channel;
  final bool showPics;
  final bool showOptionalImage;
  final bool showVehicleParameter;
  final bool showVehicleExtraImage;
  final String? agreementCoupon;
  final dynamic discountValueWithoutVat; // string o double
  final String? macroDescription;
  final bool showBookingDiscount;
  final bool? isYoungDriverAge;
  final bool? isSeniorDriverAge;

  QuotationRequest({
    required this.dropOffLocation,
    required this.endDate,
    required this.pickupLocation,
    required this.startDate,
    this.age,
    this.channel,
    this.showPics = false,
    this.showOptionalImage = false,
    this.showVehicleParameter = false,
    this.showVehicleExtraImage = false,
    this.agreementCoupon,
    this.discountValueWithoutVat,
    this.macroDescription,
    this.showBookingDiscount = false,
    this.isYoungDriverAge,
    this.isSeniorDriverAge,
  });

  Map<String, dynamic> toJson() => {
        'dropOffLocation': dropOffLocation,
        'endDate': endDate,
        'pickupLocation': pickupLocation,
        'startDate': startDate,
        if (age != null) 'age': age,
        if (channel != null) 'channel': channel,
        'showPics': showPics,
        'showOptionalImage': showOptionalImage,
        'showVehicleParameter': showVehicleParameter,
        'showVehicleExtraImage': showVehicleExtraImage,
        if (agreementCoupon != null) 'agreementCoupon': agreementCoupon,
        if (discountValueWithoutVat != null)
          'discountValueWithoutVat': discountValueWithoutVat,
        if (macroDescription != null) 'macroDescription': macroDescription,
        'showBookingDiscount': showBookingDiscount,
        if (isYoungDriverAge != null) 'isYoungDriverAge': isYoungDriverAge,
        if (isSeniorDriverAge != null) 'isSeniorDriverAge': isSeniorDriverAge,
      };
}

/* ------ Damages ------ */

class Damage {
  final String? description;
  final String? damageType;
  final String? damageDictionary;
  final int? x;
  final int? y;
  final double? percentage_x;
  final double? percentage_y;

  Damage({
    this.description,
    this.damageType,
    this.damageDictionary,
    this.x,
    this.y,
    this.percentage_x,
    this.percentage_y,
  });

  factory Damage.fromJson(Map<String, dynamic> json) => Damage(
        description: json['description'] as String?,
        damageType: json['damageType'] as String?,
        damageDictionary: json['damageDictionary'] as String?,
        x: (json['x'] as num?)?.toInt(),
        y: (json['y'] as num?)?.toInt(),
        percentage_x: (json['percentage_x'] as num?)?.toDouble(),
        percentage_y: (json['percentage_y'] as num?)?.toDouble(),
      );

  Map<String, dynamic> toJson() => {
        if (description != null) 'description': description,
        if (damageType != null) 'damageType': damageType,
        if (damageDictionary != null) 'damageDictionary': damageDictionary,
        if (x != null) 'x': x,
        if (y != null) 'y': y,
        if (percentage_x != null) 'percentage_x': percentage_x,
        if (percentage_y != null) 'percentage_y': percentage_y,
      };
}

class WireframeImage {
  final String image;
  final int height;
  final int width;

  WireframeImage({required this.image, required this.height, required this.width});

  factory WireframeImage.fromJson(Map<String, dynamic> json) => WireframeImage(
        image: json['image'] as String,
        height: (json['height'] as num).toInt(),
        width: (json['width'] as num).toInt(),
      );

  Map<String, dynamic> toJson() =>
      {'image': image, 'height': height, 'width': width};
}

class DamagesData {
  final List<Damage> damages;
  final WireframeImage wireframeImage;

  DamagesData({required this.damages, required this.wireframeImage});

  factory DamagesData.fromJson(Map<String, dynamic> json) => DamagesData(
        damages: (json['damages'] as List<dynamic>)
            .map((e) => Damage.fromJson(e as Map<String, dynamic>))
            .toList(),
        wireframeImage: WireframeImage.fromJson(
            json['wireframeImage'] as Map<String, dynamic>),
      );

  Map<String, dynamic> toJson() => {
        'damages': damages.map((e) => e.toJson()).toList(),
        'wireframeImage': wireframeImage.toJson(),
      };
}

class DamagesResponse {
  final DamagesData data;

  DamagesResponse({required this.data});

  factory DamagesResponse.fromJson(Map<String, dynamic> json) =>
      DamagesResponse(
        data: DamagesData.fromJson(json['data'] as Map<String, dynamic>),
      );

  Map<String, dynamic> toJson() => {'data': data.toJson()};
}

/* ------ Vehicles catalog ------ */

/// Item catalogo veicoli così come nel JSON originale.
/// Manteniamo solo i campi principali + un contenitore per extra.
class VehicleGroupRaw {
  final String? id; // normalizzato a String
  final String? national_code;
  final String international_code;
  final String? description;
  final String? display_name;
  final String? vendor_macro;
  final String? vehicle_type;
  final int? seats;
  final int? doors;
  final String? transmission;
  final String? fuel;
  final bool? aircon;
  final String? image_url;
  final double? daily_rate;
  final List<String> locations;
  final List<String> plates;
  final List<Map<String, dynamic>>? vehicle_parameters;
  final Map<String, dynamic>? damages;

  /// Per eventuali campi futuri non mappati
  final Map<String, dynamic> extra;

  VehicleGroupRaw({
    required this.international_code,
    this.id,
    this.national_code,
    this.description,
    this.display_name,
    this.vendor_macro,
    this.vehicle_type,
    this.seats,
    this.doors,
    this.transmission,
    this.fuel,
    this.aircon,
    this.image_url,
    this.daily_rate,
    this.locations = const [],
    this.plates = const [],
    this.vehicle_parameters,
    this.damages,
    this.extra = const {},
  });

  factory VehicleGroupRaw.fromJson(Map<String, dynamic> json) {
    final map = Map<String, dynamic>.from(json);
    final knownKeys = {
      'id',
      'national_code',
      'international_code',
      'description',
      'display_name',
      'vendor_macro',
      'vehicle_type',
      'seats',
      'doors',
      'transmission',
      'fuel',
      'aircon',
      'image_url',
      'daily_rate',
      'locations',
      'plates',
      'vehicle_parameters',
      'damages'
    };

    // estrai extra
    final leftovers = <String, dynamic>{};
    map.forEach((k, v) {
      if (!knownKeys.contains(k)) leftovers[k] = v;
    });

    return VehicleGroupRaw(
      id: map['id']?.toString(),
      national_code: map['national_code'] as String?,
      international_code: map['international_code'] as String,
      description: map['description'] as String?,
      display_name: map['display_name'] as String?,
      vendor_macro: map['vendor_macro'] as String?,
      vehicle_type: map['vehicle_type'] as String?,
      seats: (map['seats'] as num?)?.toInt(),
      doors: (map['doors'] as num?)?.toInt(),
      transmission: map['transmission'] as String?,
      fuel: map['fuel'] as String?,
      aircon: map['aircon'] as bool?,
      image_url: map['image_url'] as String?,
      daily_rate: (map['daily_rate'] as num?)?.toDouble(),
      locations: (map['locations'] as List<dynamic>? ?? [])
          .map((e) => e.toString())
          .toList(),
      plates: (map['plates'] as List<dynamic>? ?? [])
          .map((e) => e.toString())
          .toList(),
      vehicle_parameters: (map['vehicle_parameters'] as List<dynamic>?)
          ?.map((e) => Map<String, dynamic>.from(e as Map))
          .toList(),
      damages: (map['damages'] as Map?)?.cast<String, dynamic>(),
      extra: leftovers,
    );
  }

  Map<String, dynamic> toJson() => {
        if (id != null) 'id': id,
        if (national_code != null) 'national_code': national_code,
        'international_code': international_code,
        if (description != null) 'description': description,
        if (display_name != null) 'display_name': display_name,
        if (vendor_macro != null) 'vendor_macro': vendor_macro,
        if (vehicle_type != null) 'vehicle_type': vehicle_type,
        if (seats != null) 'seats': seats,
        if (doors != null) 'doors': doors,
        if (transmission != null) 'transmission': transmission,
        if (fuel != null) 'fuel': fuel,
        if (aircon != null) 'aircon': aircon,
        if (image_url != null) 'image_url': image_url,
        if (daily_rate != null) 'daily_rate': daily_rate,
        if (locations.isNotEmpty) 'locations': locations,
        if (plates.isNotEmpty) 'plates': plates,
        if (vehicle_parameters != null) 'vehicle_parameters': vehicle_parameters,
        if (damages != null) 'damages': damages,
        ...extra,
      };
}

class VehiclesPage {
  final int total;
  final int skip;
  final int page_size;
  final bool has_next;
  final int? next_skip;
  final int? prev_skip;
  final List<VehicleGroupRaw> items;

  VehiclesPage({
    required this.total,
    required this.skip,
    required this.page_size,
    required this.has_next,
    this.next_skip,
    this.prev_skip,
    required this.items,
  });

  factory VehiclesPage.fromJson(Map<String, dynamic> json) => VehiclesPage(
        total: (json['total'] as num).toInt(),
        skip: (json['skip'] as num).toInt(),
        page_size: (json['page_size'] as num).toInt(),
        has_next: json['has_next'] as bool,
        next_skip: (json['next_skip'] as num?)?.toInt(),
        prev_skip: (json['prev_skip'] as num?)?.toInt(),
        items: (json['items'] as List<dynamic>)
            .map((e) => VehicleGroupRaw.fromJson(e as Map<String, dynamic>))
            .toList(),
      );

  Map<String, dynamic> toJson() => {
        'total': total,
        'skip': skip,
        'page_size': page_size,
        'has_next': has_next,
        if (next_skip != null) 'next_skip': next_skip,
        if (prev_skip != null) 'prev_skip': prev_skip,
        'items': items.map((e) => e.toJson()).toList(),
      };
}

class ReservationComposeRequest {
  final JsonMap booking;
  final JsonMap customer;
  final JsonMap? customerUpdate;
  final JsonMap? driver1;
  final JsonMap? driver2;
  final JsonMap? driver3;

  ReservationComposeRequest({
    required this.booking,
    required this.customer,
    this.customerUpdate,
    this.driver1,
    this.driver2,
    this.driver3,
  });

  Map<String, dynamic> toJson() => {
        'booking': booking,
        'customer': customer,
        if (customerUpdate != null) 'customerUpdate': customerUpdate,
        if (driver1 != null) 'driver1': driver1,
        if (driver2 != null) 'driver2': driver2,
        if (driver3 != null) 'driver3': driver3,
      };
}

class ReservationComposeResponse {
  final String booking_id;
  final String reservation_id_internal;
  final String? customer_id;
  final String channel;

  final JsonMap booking_create;
  final JsonMap booking_detail;

  final JsonMap? customer_before_update;
  final JsonMap? customer_after_update;

  final bool used_customer_as_driver1;
  final JsonMap? set_customer_as_driver1_result;
  final JsonMap? driver1_result;
  final JsonMap? driver2_result;
  final JsonMap? driver3_result;

  ReservationComposeResponse({
    required this.booking_id,
    required this.reservation_id_internal,
    required this.customer_id,
    required this.channel,
    required this.booking_create,
    required this.booking_detail,
    required this.customer_before_update,
    required this.customer_after_update,
    required this.used_customer_as_driver1,
    required this.set_customer_as_driver1_result,
    required this.driver1_result,
    required this.driver2_result,
    required this.driver3_result,
  });

  factory ReservationComposeResponse.fromJson(Map<String, dynamic> json) =>
      ReservationComposeResponse(
        booking_id: json['booking_id'].toString(),
        reservation_id_internal: json['reservation_id_internal'].toString(),
        customer_id: json['customer_id']?.toString(),
        channel: json['channel'] as String,
        booking_create:
            Map<String, dynamic>.from(json['booking_create'] as Map? ?? {}),
        booking_detail:
            Map<String, dynamic>.from(json['booking_detail'] as Map? ?? {}),
        customer_before_update: json['customer_before_update'] == null
            ? null
            : Map<String, dynamic>.from(
                json['customer_before_update'] as Map),
        customer_after_update: json['customer_after_update'] == null
            ? null
            : Map<String, dynamic>.from(
                json['customer_after_update'] as Map),
        used_customer_as_driver1:
            (json['used_customer_as_driver1'] ?? false) as bool,
        set_customer_as_driver1_result:
            json['set_customer_as_driver1_result'] == null
                ? null
                : Map<String, dynamic>.from(
                    json['set_customer_as_driver1_result'] as Map),
        driver1_result: json['driver1_result'] == null
            ? null
            : Map<String, dynamic>.from(json['driver1_result'] as Map),
        driver2_result: json['driver2_result'] == null
            ? null
            : Map<String, dynamic>.from(json['driver2_result'] as Map),
        driver3_result: json['driver3_result'] == null
            ? null
            : Map<String, dynamic>.from(json['driver3_result'] as Map),
      );

  Map<String, dynamic> toJson() => {
        'booking_id': booking_id,
        'reservation_id_internal': reservation_id_internal,
        if (customer_id != null) 'customer_id': customer_id,
        'channel': channel,
        'booking_create': booking_create,
        'booking_detail': booking_detail,
        if (customer_before_update != null)
          'customer_before_update': customer_before_update,
        if (customer_after_update != null)
          'customer_after_update': customer_after_update,
        'used_customer_as_driver1': used_customer_as_driver1,
        if (set_customer_as_driver1_result != null)
          'set_customer_as_driver1_result': set_customer_as_driver1_result,
        if (driver1_result != null) 'driver1_result': driver1_result,
        if (driver2_result != null) 'driver2_result': driver2_result,
        if (driver3_result != null) 'driver3_result': driver3_result,
      };
}

class ReservationFullDetailsResponse {
  final String reservation_id_internal;
  final String booking_id;
  final String channel;
  final String? customer_id;

  final JsonMap booking_detail;
  final JsonMap? customer;

  final bool? used_customer_as_driver1;
  final JsonMap? set_customer_as_driver1_result;
  final JsonMap? driver1_result;
  final JsonMap? driver2_result;
  final JsonMap? driver3_result;

  final JsonMap? reservation_web_checkin;

  final String? customer_first_name;
  final String? customer_last_name;

  final String? driver1;
  final int? driver1_id;
  final String? driver2;
  final int? driver2_id;
  final String? driver3;
  final int? driver3_id;

  ReservationFullDetailsResponse({
    required this.reservation_id_internal,
    required this.booking_id,
    required this.channel,
    required this.customer_id,
    required this.booking_detail,
    required this.customer,
    required this.used_customer_as_driver1,
    required this.set_customer_as_driver1_result,
    required this.driver1_result,
    required this.driver2_result,
    required this.driver3_result,
    required this.reservation_web_checkin,
    required this.customer_first_name,
    required this.customer_last_name,
    required this.driver1,
    required this.driver1_id,
    required this.driver2,
    required this.driver2_id,
    required this.driver3,
    required this.driver3_id,
  });

  factory ReservationFullDetailsResponse.fromJson(Map<String, dynamic> json) =>
      ReservationFullDetailsResponse(
        reservation_id_internal: json['reservation_id_internal'].toString(),
        booking_id: json['booking_id'].toString(),
        channel: json['channel'] as String,
        customer_id: json['customer_id']?.toString(),
        booking_detail:
            Map<String, dynamic>.from(json['booking_detail'] as Map? ?? {}),
        customer: json['customer'] == null
            ? null
            : Map<String, dynamic>.from(json['customer'] as Map),
        used_customer_as_driver1: json['used_customer_as_driver1'] as bool?,
        set_customer_as_driver1_result:
            json['set_customer_as_driver1_result'] == null
                ? null
                : Map<String, dynamic>.from(
                    json['set_customer_as_driver1_result'] as Map),
        driver1_result: json['driver1_result'] == null
            ? null
            : Map<String, dynamic>.from(json['driver1_result'] as Map),
        driver2_result: json['driver2_result'] == null
            ? null
            : Map<String, dynamic>.from(json['driver2_result'] as Map),
        driver3_result: json['driver3_result'] == null
            ? null
            : Map<String, dynamic>.from(json['driver3_result'] as Map),
        reservation_web_checkin: json['reservation_web_checkin'] == null
            ? null
            : Map<String, dynamic>.from(json['reservation_web_checkin'] as Map),
        customer_first_name: json['customer_first_name'] as String?,
        customer_last_name: json['customer_last_name'] as String?,
        driver1: json['driver1'] as String?,
        driver1_id: (json['driver1_id'] as num?)?.toInt(),
        driver2: json['driver2'] as String?,
        driver2_id: (json['driver2_id'] as num?)?.toInt(),
        driver3: json['driver3'] as String?,
        driver3_id: (json['driver3_id'] as num?)?.toInt(),
      );

  Map<String, dynamic> toJson() => {
        'reservation_id_internal': reservation_id_internal,
        'booking_id': booking_id,
        'channel': channel,
        if (customer_id != null) 'customer_id': customer_id,
        'booking_detail': booking_detail,
        if (customer != null) 'customer': customer,
        if (used_customer_as_driver1 != null)
          'used_customer_as_driver1': used_customer_as_driver1,
        if (set_customer_as_driver1_result != null)
          'set_customer_as_driver1_result': set_customer_as_driver1_result,
        if (driver1_result != null) 'driver1_result': driver1_result,
        if (driver2_result != null) 'driver2_result': driver2_result,
        if (driver3_result != null) 'driver3_result': driver3_result,
        if (reservation_web_checkin != null)
          'reservation_web_checkin': reservation_web_checkin,
        if (customer_first_name != null)
          'customer_first_name': customer_first_name,
        if (customer_last_name != null)
          'customer_last_name': customer_last_name,
        if (driver1 != null) 'driver1': driver1,
        if (driver1_id != null) 'driver1_id': driver1_id,
        if (driver2 != null) 'driver2': driver2,
        if (driver2_id != null) 'driver2_id': driver2_id,
        if (driver3 != null) 'driver3': driver3,
        if (driver3_id != null) 'driver3_id': driver3_id,
      };
}

